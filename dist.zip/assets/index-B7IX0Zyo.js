const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BumgvzeY.js","assets/index-Btw7m8Xq.js","assets/index-v4Z_9h_c.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-Btw7m8Xq.js";const _=p("App",{web:()=>r(()=>import("./web-BumgvzeY.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
