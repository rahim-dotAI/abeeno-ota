const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B3FDErdp.js","assets/index-BcTh5HpE.js","assets/index-mB12GR9O.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BcTh5HpE.js";const _=p("App",{web:()=>r(()=>import("./web-B3FDErdp.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
