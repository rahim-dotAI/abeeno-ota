const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Qc2WQ-Lg.js","assets/index-BLo2vgZE.js","assets/index-BS_oinTi.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BLo2vgZE.js";const _=p("App",{web:()=>r(()=>import("./web-Qc2WQ-Lg.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
