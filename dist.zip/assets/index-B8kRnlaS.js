const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B16fAwN7.js","assets/index-Ccn99aJj.js","assets/index-FHlo3P1P.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-Ccn99aJj.js";const _=p("App",{web:()=>r(()=>import("./web-B16fAwN7.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
