import{r as i}from"./index-DUlvbc4d.js";const t=i("PushNotifications",{});export{t as PushNotifications};
