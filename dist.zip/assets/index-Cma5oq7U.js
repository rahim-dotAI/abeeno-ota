const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Cc9_cB-x.js","assets/index-Dw-LcZx5.js","assets/index-BS_oinTi.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-Dw-LcZx5.js";const _=p("App",{web:()=>r(()=>import("./web-Cc9_cB-x.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
