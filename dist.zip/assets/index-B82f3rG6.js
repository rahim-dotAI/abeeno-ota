const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Br2X4-Qs.js","assets/index-BQDxB_a9.js","assets/index-FHlo3P1P.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BQDxB_a9.js";const _=p("App",{web:()=>r(()=>import("./web-Br2X4-Qs.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
