const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Ck2prHAJ.js","assets/index-C6Qm9J1l.js","assets/index-CLQhJI0-.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-C6Qm9J1l.js";const _=p("App",{web:()=>r(()=>import("./web-Ck2prHAJ.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
