const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CrEn5Amf.js","assets/index-bh4E0QlE.js","assets/index-BDTpCtQt.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-bh4E0QlE.js";const _=p("App",{web:()=>r(()=>import("./web-CrEn5Amf.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
