const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Drk5ERTz.js","assets/index-BvAXyDgP.js","assets/index-BPqr_Jzm.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BvAXyDgP.js";const _=p("App",{web:()=>r(()=>import("./web-Drk5ERTz.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
