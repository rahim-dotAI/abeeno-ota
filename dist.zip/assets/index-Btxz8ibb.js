const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C-Ua8rKY.js","assets/index-BQl2wM7I.js","assets/index-BS_oinTi.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BQl2wM7I.js";const _=p("App",{web:()=>r(()=>import("./web-C-Ua8rKY.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
