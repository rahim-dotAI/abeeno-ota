const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C967lBkH.js","assets/index-BioThAal.js","assets/index-CsOzYzFy.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BioThAal.js";const _=p("App",{web:()=>r(()=>import("./web-C967lBkH.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
