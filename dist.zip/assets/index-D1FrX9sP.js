const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CMMygRy6.js","assets/index-CEFL4G9h.js","assets/index-CPuE9XnX.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-CEFL4G9h.js";const _=p("App",{web:()=>r(()=>import("./web-CMMygRy6.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
