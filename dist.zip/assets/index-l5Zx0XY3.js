const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CYiuORzF.js","assets/index-B2WmkCUw.js","assets/index-BDTpCtQt.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-B2WmkCUw.js";const _=p("App",{web:()=>r(()=>import("./web-CYiuORzF.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
