const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BeKKVlc1.js","assets/index-Ch0qntEp.js","assets/index-CsOzYzFy.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-Ch0qntEp.js";const _=p("App",{web:()=>r(()=>import("./web-BeKKVlc1.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
