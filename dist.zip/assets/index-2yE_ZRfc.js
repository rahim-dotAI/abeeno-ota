const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-O3u6gfJE.js","assets/index-DrIeblam.js","assets/index-CsOzYzFy.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-DrIeblam.js";const _=p("App",{web:()=>r(()=>import("./web-O3u6gfJE.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
