const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DdJkHVQn.js","assets/index-BiSQgWIj.js","assets/index-BPqr_Jzm.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BiSQgWIj.js";const _=p("App",{web:()=>r(()=>import("./web-DdJkHVQn.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
