const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-xzk5Ztf8.js","assets/index-eYggQEvB.js","assets/index-BPqr_Jzm.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-eYggQEvB.js";const _=p("App",{web:()=>r(()=>import("./web-xzk5Ztf8.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
