const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DHSVF4H7.js","assets/index-CWHVH88k.js","assets/index-CRalaDrl.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-CWHVH88k.js";const _=p("App",{web:()=>r(()=>import("./web-DHSVF4H7.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
