import{r as i}from"./index-_awVJtxq.js";const t=i("PushNotifications",{});export{t as PushNotifications};
