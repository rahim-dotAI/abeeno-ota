const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C2SCQAtB.js","assets/index-IpCYUaxB.js","assets/index-yXGoUfCM.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-IpCYUaxB.js";const _=p("App",{web:()=>r(()=>import("./web-C2SCQAtB.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
