const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Bmm7aTQh.js","assets/index-C2e3kCBy.js","assets/index-v4Z_9h_c.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-C2e3kCBy.js";const _=p("App",{web:()=>r(()=>import("./web-Bmm7aTQh.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
