const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-ktWfeT3r.js","assets/index-B4VEYGnf.js","assets/index-CsOzYzFy.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-B4VEYGnf.js";const _=p("App",{web:()=>r(()=>import("./web-ktWfeT3r.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
